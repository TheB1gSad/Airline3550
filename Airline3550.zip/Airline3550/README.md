# Airline3550
Software Engineering 3550 Project

Software meant to emulate an airports software that is used to schedule, book flights 
in addition to being able to keep track of the financial records of the airline. Has a 
user system that requires login credentials to access different parts of the system based
on what type of user is logged in.

Main Menu Splash Image Courtesy of https://www.pexels.com/photo/white-and-gray-airplane-249581/


Instructions:

  Extract Zip Named Airline3550.zip

  Open Folder

  Double click on Airline3550.exe

  Enter Credentials or Make New Account

  If you would like to sign in as a non customer account some sample logins are as follows

  Load Engineer:
    User ID: 794096
    Password: 123

  Flight Manager: 
    User ID: 123456
    Password: 123
  
  Accountant:
    User ID: 654321
    Password: 123


  If you would like a customer account preloaded with sales:
    User ID: 142823
    Password: 123